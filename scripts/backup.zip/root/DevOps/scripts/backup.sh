#!/bin/bash

timestamp=$(date '+%Y%m%D_%H%M%S')
echo $timestamp
function create_backup() {
	zip -r backup.zip /root/DevOps/scripts/ 
}

create_backup
