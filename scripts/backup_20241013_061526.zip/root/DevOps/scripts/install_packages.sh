#!/bin/bash
echo "******** INSTALLING $1 ********"

yum install $1 -y
