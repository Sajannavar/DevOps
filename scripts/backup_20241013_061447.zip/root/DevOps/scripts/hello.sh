#!/bin/bash

echo "This is shell scripting"

date
